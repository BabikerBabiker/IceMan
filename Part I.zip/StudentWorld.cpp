#include "StudentWorld.h"
#include <string>
#include <cmath>
#include <ctime>
#include <iomanip>
using namespace std;

GameWorld* createStudentWorld(string assetDir)
{
	return new StudentWorld(assetDir);
}

// Students:  Add code to this file (if you wish), StudentWorld.h, Actor.h and Actor.cpp

int StudentWorld::init() {
	Actors.clear();

	// setDisplayText(); -- Commented out to turn in Part I

	Iceman = new IceMan (30, 60, this);
	Actors.push_back(Iceman);

	for (int x = 0; x < 64; ++x) {
		for (int y = 0; y < 60; ++y) {
			if (x >= 30 && x <= 33 && y >= 4) {
				IceField[x][y] = nullptr;
			}
			else {
				IceField[x][y] = new Ice(x, y, this);
			}
		}
	}

	int current_level_number = getLevel();
	int B = std::min(current_level_number / 2 + 2, 9);

	srand(static_cast<unsigned int>(time(0)));

	for (int i = 0; i < B; ++i) {
		int x, y;
		bool placed = false;
		while (!placed) {
			x = rand() % 61;
			y = rand() % 37 + 20;

			if ((x < 30 || x > 33) && !overlap(x, y)) {
				Boulder* boulder = new Boulder(x, y, this);
				Actors.push_back(boulder);

				for (int bx = x; bx < x + 4; ++bx) {
					for (int by = y; by < y + 4; ++by) {
						removeIce(bx, by);
					}
				}

				placed = true;
			}
		}
	}
	return GWSTATUS_CONTINUE_GAME;
}
int StudentWorld::move() {
	// This code is here merely to allow the game to build, run, and terminate after you hit enter a few times.
	// Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
	Iceman->doSomething();
	return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp() {
	for (int i = 0; i < 4096; i++) {
		if (IceField[i] == nullptr) {
			return;
		}
		delete IceField[i];
	}
	delete Iceman;
	return;

}

bool StudentWorld::overlap(int x, int y) const{
	// implement this function, temporarily put as false to compile for part I
	return false; 
}

void StudentWorld::removeIce(int x, int y) {
	if (x >= 0 && x < VIEW_WIDTH && y >= 0 && y < VIEW_HEIGHT) {
		if (IceField[x][y] != nullptr) {
			playSound(SOUND_DIG);
			delete IceField[x][y];
			IceField[x][y] = nullptr;
		}
	}
}

// -- Commented out for Part I
//void StudentWorld::setDisplayText() {
//	int level = getLevel();
//	int lives = getLives();
//	int health = getHealth();
//	int water = getWater();
//	int gold = getGold();
//	int oilLeft = getOilLeft();
//	int sonar = getSonar();
//	int score = getScore();
//
//	std::ostringstream oss;
//	oss << "Lvl: " << level
//		<< " Lives: " << lives
//		<< " Hlth: " << std::setw(3) << health << '%'
//		<< " Wtr: " << water
//		<< " Gld: " << gold
//		<< " Oil Left: " << oilLeft
//		<< " Sonar: " << sonar
//		<< " Scr: " << score;
//
//	setGameStatText(oss.str());
//}