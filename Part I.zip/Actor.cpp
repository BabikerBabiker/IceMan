#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

void IceMan::doSomething() {
    if (!isAlive())
        return;

    StudentWorld* world = getWorld();
    if (!world)
        return;

    int key;
    if (GameController::getInstance().getLastKey(key)) {
        int newX = getX();
        int newY = getY();
        switch (key) {
        case KEY_PRESS_LEFT:
            if (newX > 0) {
                setDirection(left);
                newX--;
            }
            break;
        case KEY_PRESS_RIGHT:
            if (newX < VIEW_WIDTH - 1) {
                setDirection(right);
                newX++;
            }
            break;
        case KEY_PRESS_UP:
            if (newY < VIEW_HEIGHT - 1) {
                setDirection(up);
                newY++;
            }
            break;
        case KEY_PRESS_DOWN:
            if (newY > 0) {
                setDirection(down);
                newY--;
            }
            break;
        }
        if (newX != getX() || newY != getY()) {
            moveTo(newX, newY);
            for (int x = newX; x < newX + 4; ++x) {
                for (int y = newY; y < newY + 4; ++y) {
                    world->removeIce(x, y);
                }
            }
        }
    }
}