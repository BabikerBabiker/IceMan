#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <string>
#include <vector>
#include <algorithm>

class Actor;
class IceMan;
class Ice;

class StudentWorld : public GameWorld {
public:
    StudentWorld(std::string assetDir) : GameWorld(assetDir) {
        for (int i = 0; i < VIEW_WIDTH; ++i) {
            for (int j = 0; j < VIEW_HEIGHT; ++j) {
                IceField[i][j] = nullptr;
            }
        }
    }

    virtual ~StudentWorld() {
        cleanUp();
    }

    virtual int init();
    virtual int move();
    virtual void cleanUp();
    bool overlap(int x, int y) const;
    void removeIce(int x, int y);
    void setDisplayText();

private:
    std::vector<Actor*> Actors;
    int level{};
    IceMan* Iceman;
    int num_ice{};
    int num_boulders{};
    int num_gold{};
    int num_barrels{};
    int inv_barrels{};
    int num_protestors{};
    int ticks_wait{};
    int ticks_since{};
    char actor_pos[64][64];
    Ice* IceField[64][64];

    // -- Commented out for part 1
    //int getLevel() const { return level; }
    //int getLives() const { return 0; } // implement it
    //int getHealth() const { return 0; } // implement it
    //int getWater() const { return 0; } // implement it
    //int getGold() const { return 0; } // implement it
    //int getOilLeft() const { return num_barrels - inv_barrels; }
    //int getSonar() const { return 0; } // implement it
    //int getScore() const { return 0; } // implement it
};

#endif // STUDENTWORLD_H_
